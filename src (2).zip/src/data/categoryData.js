const categoriesData = [
  {
    id: 1,
    categoryName: "Burger",
    products: [],
  },
  {
    id: 2,
    categoryName: "Lavash",
    products: [],
  },
  {
    id: 3,
    categoryName: "Garniyer",
    products: [],
  },
  {
    id: 4,
    categoryName: "Salatlar",
    products: [],
  },
  {
    id: 5,
    categoryName: "Sendvich",
    products: [],
  },
  {
    id: 5,
    categoryName: "Sous",
    products: [],
  },
];

export default categoriesData;
