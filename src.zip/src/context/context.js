import { createContext } from "react";

const ApiContext = createContext({
  orders: [],
  setOrderes: (orders) => {},
  products: [],
  setProducts: (products) => {},
});

export default ApiContext;
