const categoriesData = [
  {
    id: 1,
    categoryName: "Burger",
    products: [
      {
        id: 1,
        productName: "ChizburgerMax",
        price: 23000,
        extra: "Kichkina lavash",
        productImage:
          "https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/1:1/w_2560%2Cc_limit/Smashburger-recipe-120219.jpg",
      },
      {
        id: 1,
        productName: "Burger mini",
        price: 11000,
        extra: "Ays tea",
        productImage:
          "https://g2fly.ru/image/catalog/Furshet/%D0%9C%D0%B8%D0%BD%D0%B8-%D0%B1%D1%83%D1%80%D0%B3%D0%B5%D1%80-min.jpg",
      },
    ],
  },
  {
    id: 2,
    categoryName: "Lavash",
    products: [
      {
        id: 1,
        productName: "Lavash mini",
        price: 23000,
        extra: "Dena 0.5l",
        productImage:
          "https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/1:1/w_2560%2Cc_limit/Smashburger-recipe-120219.jpg",
      },
      {
        id: 1,
        productName: "Lavash Max",
        price: 11000,
        extra: "Fuse tea",
        productImage:
          "https://g2fly.ru/image/catalog/Furshet/%D0%9C%D0%B8%D0%BD%D0%B8-%D0%B1%D1%83%D1%80%D0%B3%D0%B5%D1%80-min.jpg",
      },
    ],
  },
  {
    id: 3,
    categoryName: "Garniyer",
    products: [
      {
        id: 1,
        productName: "Garnier 1",
        price: 23000,
        extra: "Kichkina lavash",
        productImage:
          "https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/1:1/w_2560%2Cc_limit/Smashburger-recipe-120219.jpg",
      },
      {
        id: 1,
        productName: "Garnier 2",
        price: 11000,
        extra: "Ays tea",
        productImage:
          "https://g2fly.ru/image/catalog/Furshet/%D0%9C%D0%B8%D0%BD%D0%B8-%D0%B1%D1%83%D1%80%D0%B3%D0%B5%D1%80-min.jpg",
      },
    ],
  },
  {
    id: 4,
    categoryName: "Salatlar",
    products: [
      {
        id: 1,
        productName: "Salatlar 1",
        price: 23000,
        extra: "Kichkina lavash",
        productImage:
          "https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/1:1/w_2560%2Cc_limit/Smashburger-recipe-120219.jpg",
      },
      {
        id: 1,
        productName: "Salatlar 2",
        price: 11000,
        extra: "Ays tea",
        productImage:
          "https://g2fly.ru/image/catalog/Furshet/%D0%9C%D0%B8%D0%BD%D0%B8-%D0%B1%D1%83%D1%80%D0%B3%D0%B5%D1%80-min.jpg",
      },
    ],
  },
  {
    id: 5,
    categoryName: "Salatlar",
    products: [
      {
        id: 1,
        productName: "Salatlar 1",
        price: 23000,
        extra: "Kichkina lavash",
        productImage:
          "https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/1:1/w_2560%2Cc_limit/Smashburger-recipe-120219.jpg",
      },
      {
        id: 1,
        productName: "Salatlar 2",
        price: 11000,
        extra: "Ays tea",
        productImage:
          "https://g2fly.ru/image/catalog/Furshet/%D0%9C%D0%B8%D0%BD%D0%B8-%D0%B1%D1%83%D1%80%D0%B3%D0%B5%D1%80-min.jpg",
      },
    ],
  },
  {
    id: 5,
    categoryName: "Sous",
    products: [
      {
        id: 1,
        productName: "Sous 1",
        price: 23000,
        extra: "Eritilgan sir",
        productImage:
          "https://assets.epicurious.com/photos/5c745a108918ee7ab68daf79/1:1/w_2560%2Cc_limit/Smashburger-recipe-120219.jpg",
      },
      {
        id: 1,
        productName: "Salatlar 2",
        price: 11000,
        extra: "Ays tea",
        productImage:
          "https://g2fly.ru/image/catalog/Furshet/%D0%9C%D0%B8%D0%BD%D0%B8-%D0%B1%D1%83%D1%80%D0%B3%D0%B5%D1%80-min.jpg",
      },
    ],
  },
];

export default categoriesData;
